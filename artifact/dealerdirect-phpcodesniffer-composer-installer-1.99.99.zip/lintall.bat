@echo off
REM Lint all PHP files
REM

call parallel-lint . -e php --exclude vendor --exclude .git --exclude tests/fixtures --exclude TEMP
