@echo off
REM Run the tests against all supported PHP minor combinations
REM


:: PHPUnit 4 - officially supported on PHP 5.3 - 5.5
::echo "PHP 5.3.29"
::call "C:\wamp\bin\phpcli_x86\php5.3.29\php.exe" "C:\bin\phars\phpunit-4.8.36.phar" --disallow-test-output --no-coverage %* || ECHO 
echo "PHP 5.4.45"
call "C:\wamp\bin\phpcli_x86\php5.4.45\php.exe" "C:\bin\phars\phpunit-4.8.36.phar" --disallow-test-output --no-coverage %* || ECHO 
echo "PHP 5.5.38"
call "C:\wamp\bin\php\php5.5.38\php.exe" "C:\bin\phars\phpunit-4.8.36.phar" --disallow-test-output --no-coverage %* || ECHO 


:: PHPUnit 5 - officially supported on PHP 5.6 - 7.1
echo "PHP 5.6.40"
call "C:\wamp\bin\php\php5.6.40\php.exe" "C:\bin\phars\phpunit-5.7.27.phar" --disallow-test-output --no-coverage %* || ECHO 


:: PHPUnit 6 - officially supported on PHP 7.0 - 7.2
echo "PHP 7.0.33"
call "C:\wamp\bin\php\php7.0.33\php.exe" "C:\bin\phars\phpunit-6.5.14.phar" --disallow-test-output --no-coverage %* || ECHO 


:: PHPUnit 7 - officially supported on PHP 7.1 - 7.3
echo "PHP 7.1.33"
call "C:\wamp\bin\php\php7.1.33\php.exe" "C:\bin\phars\phpunit-7.5.20.phar" --disallow-test-output --no-coverage %* || ECHO 


:: PHPUnit 8 - officially supported on PHP 7.2 - 8.0
echo "PHP 7.2.34"
call "C:\wamp\bin\php\php7.2.34\php.exe" "C:\bin\phars\phpunit-8.5.42.phar" --disallow-test-output --no-coverage %* || ECHO 


:: PHPUnit 9 - officially supported on PHP 7.3 - 7.4, PHP 8
echo "PHP 7.3.33"
call "C:\wamp\bin\php\php7.3.33\php.exe" "C:\bin\phars\phpunit-9.6.23.phar" --disallow-test-output --no-coverage %* || ECHO 
echo "PHP 7.4.33"
call "C:\wamp\bin\php\php7.4.33\php.exe" "C:\bin\phars\phpunit-9.6.23.phar" --disallow-test-output --no-coverage %* || ECHO 
echo "PHP 8.0.28"
call "C:\wamp\bin\php\php8.0.30\php.exe" "C:\bin\phars\phpunit-9.6.23.phar" --disallow-test-output --no-coverage %* || ECHO 

echo "PHP 8.1.17"
call "C:\wamp\bin\php\php8.1.33\php.exe" "C:\bin\phars\phpunit-9.6.23.phar" --disallow-test-output --no-coverage %* || ECHO 

echo "PHP 8.2.x"
call "C:\wamp\bin\php\php8.2.29\php.exe" "C:\bin\phars\phpunit-9.6.23.phar" --disallow-test-output --no-coverage %* || ECHO 

echo "PHP 8.3.x"
call "C:\wamp\bin\php\php8.3.23\php.exe" "C:\bin\phars\phpunit-9.6.23.phar" --disallow-test-output --no-coverage %* || ECHO 

echo "PHP 8.4.x"
call "C:\wamp\bin\php\php8.4.10\php.exe" "C:\bin\phars\phpunit-9.6.23.phar" --disallow-test-output --no-coverage %* || ECHO 


:: PHPUnit 10 - officially supported on PHP 8.1 -
::echo "PHP 8.1.17"
::call "C:\wamp\bin\php\php8.1.33\php.exe" "C:\bin\phars\phpunit-10.5.47.phar" --disallow-test-output --no-coverage %* || ECHO 

::echo "PHP 8.2.x"
::call "C:\wamp\bin\php\php8.2.29\php.exe" "C:\bin\phars\phpunit-10.5.47.phar" --disallow-test-output --no-coverage %* || ECHO 

::echo "PHP 8.3.x"
::call "C:\wamp\bin\php\php8.3.23\php.exe" "C:\bin\phars\phpunit-10.5.47.phar" --disallow-test-output --no-coverage %* || ECHO 

::echo "PHP 8.4.x"
::call "C:\wamp\bin\php\php8.4.10\php.exe" "C:\bin\phars\phpunit-10.5.47.phar" --disallow-test-output --no-coverage %* || ECHO 



ECHO 
ECHO 
